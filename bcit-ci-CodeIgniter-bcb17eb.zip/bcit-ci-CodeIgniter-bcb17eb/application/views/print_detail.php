
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <th>tgl_pengaduan</th>
            <th>isi_pengadaun</th> 
            <th>foto</th>
            <th>status</th>
            </tr>
            <?php 
            $no=1;
            foreach ($datalaporan as $datalaporan) ?>
            <tr>
                <td><?php echo $tgl_pengaduan ?></td>
                <td><?php echo $datalaporan->tgl_pengaduan ?></td>
                <td><?php echo $datalaporan->foto ?></td>
                <td><?php echo $datalaporan->status ?></td>
        </tr>
        <?php endforeach; ?>
</table>
<script type="text/javascript'
</script
    </table>
</body>
</html>
