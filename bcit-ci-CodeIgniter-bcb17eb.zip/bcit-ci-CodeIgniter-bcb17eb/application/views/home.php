<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1><!DOCTYPE html>
<html lang="en">
<head>
    <title>home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        .box{
            height: 262px;
            width: 1110; 
        }
body {
  background-image: url('http://www.smkmutucikampek.sch.id/wp-content/uploads/2021/06/123-300x138.jpeg');
  background-repeat: no-repeat; 
  background-size: cover;
}
    </style>
</head>
    <div class="container mt-5">
    <h1 class="text-black">DATA SISWA</h1>
    <div class="card text-center">
  <div class="card-header">
    <ul class="nav nav-pills card-header-pills">
      <li class="nav-item">
      </li>
      <li class="nav-item">
        <a class="nav-link text-dark" href="tampil">TAMPIL</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-dark" href="tambah">TAMBAH SISWA</a>
      </li>
    </ul>
  </div>
</div>
<div class="container mt-5 text-center">
    <div class="box border border-light bg-white">
        <h4 class="mt-5">WELCOME TO SMK TI MUHAMMADIYAH CIKAMPEK </h4>
    </div>
</div>

</a>
</div>
</body>
</html> </h1>

</body>
</html>